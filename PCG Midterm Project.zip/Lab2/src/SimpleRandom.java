/*
 * Leonard Maxim
 *
 * PRNG using the Linear congruential generator algorithm (https://en.wikipedia.org/wiki/Linear_congruential_generator)
 * Used only for illustrating a possible implementation of a random number generator class
 */

public class SimpleRandom {
	int seed = 49; // initial value for the algorithm
	private int iterator = 0; // keeps track of the last random number generated
	private int a = 8121, m = 134456, c = 28411; // static variables (more info in the wiki page)

	// constructor with given seed
	SimpleRandom(int seed) {
		this.seed = seed;
		iterator = seed;
		// we initialize the iterator with the seed's value because
		// we want to keep track of what the seed does and the iterator
		// keeps track of the last RNG
	}

	// default constructor
	SimpleRandom() {
		iterator = seed;
	}

	// returns a random number
	int nextInt() {
		iterator = rand(iterator);
		return iterator;
	}

	// returns a random number in range [min, max]
	int nextInt(int min, int max) {
		iterator = rand(iterator);
		return (min + (iterator) % (max - min + 1));
	}

	// actual LCG algorithm
	// private int rand(int val)
	int rand(int val)

	{
		// TODO: Implement function
		int randomNum = (a * seed + c) % m;
		return randomNum;
	}

	int[] randArray(int n, int min, int max) {
		// TODO: Implement function
		int[] newArray = new int[n];
		for (int i = 0; i < n; i++) {
			if (rand(i) > min && rand(i) < max) {
				newArray[i] = rand(i);
			}
		}

		return newArray;

	}

}