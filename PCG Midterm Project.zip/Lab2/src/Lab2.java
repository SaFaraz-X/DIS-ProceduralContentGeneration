import java.awt.Color;

public class Lab2 {

	static SimpleRandom simpleR = new SimpleRandom();

	/*
	 * Recursive function that adds the first n numbers and returns the result
	 */
	static int Add(int n) {
		if (n == 0) {
			return 0;
		} else if (n == 1) {
			return 1;
		} else {
			n = n + Add(n - 1);
			return n;
		}

	}

	/*
	 * Recursive function that returns the Fibonacci sequence of the first seqNum
	 * elements
	 */
	static int Fibonacci(int prevNum, int num, int seqNum) {
		if (seqNum < 2) {
			return num;
		} else {
			System.out.print(num + ",");
			int results = Fibonacci(num, num + prevNum, seqNum - 1);
			return results;

		}
	}

	/*
	 * Recursive function that draws a square spiral starting where the length
	 * parameter is the inital length of the first side that's drawn and the length
	 * of the line drawn changes with every iteration, becoming 0.9 times smaller
	 * than the previous line.
	 * 
	 * The minLength parameter indicates that the recursive function should
	 * terminate (the base case) once the length parameter is less than the
	 * minLength
	 */
	static void DrawSquareSpiral(double length, int minLength, Turtle turtle) {
		if (length < minLength) {
			return;
		} else {
			SimpleRandom simpleR = new SimpleRandom();
			int newVal = simpleR.nextInt(10, 100);
			String newColor = Integer.toString(newVal);
			turtle.penColor(newColor);
			turtle.forward(length);
			turtle.right(90);
			DrawSquareSpiral(length * 0.9, minLength, turtle);
		}
	}

	/*
	 * A recursive function similar to the previous method and adds two extra
	 * parameter (scaleFactor and angle) so that I don't need to hardcode the values
	 * for the angle and scaling of the image, and put them in variables to get more
	 * variation from the function
	 */
	static void DrawSpiral(double length, double angle, double scaleFactor, int minLength, Turtle secondTurtle) {
		if (length < minLength) {
			return;
		} else {
			secondTurtle.forward(length);
			secondTurtle.left(angle);
			DrawSpiral(length * scaleFactor, angle, scaleFactor, minLength, secondTurtle);
		}
	}

	/*
	 * This recursive function modifies the DrawSpiral function by changing the
	 * color of the turtle to a random color after each iteration
	 */
	static void DrawSpiralWithColors(double length, double angle, double scaleFactor, int minLength,
			Turtle secondTurtle) {
		if (length < minLength) {
			return;
		} else {
			secondTurtle.forward(length);
			secondTurtle.left(angle);
			secondTurtle.penColor(new Color((int) (Math.random() * 0x1000000)));
			DrawSpiralWithColors(length * scaleFactor, angle, scaleFactor, minLength, secondTurtle);
		}
	}

	/*
	 * This function uses the DrawSpiralWithColors method in order to create
	 * something with a cool pattern, something that looks more like a fractal
	 */
	static void DrawWeirdStuff(int iterations, Turtle turtle) {
		if (iterations <= 1) {
			return;
		} else {
			DrawSpiralWithColors(simpleR.nextInt(10, 100), 20, 0.95, 5, turtle);
			turtle.right(simpleR.nextInt(0, 180));
			turtle.forward(200);
			DrawWeirdStuff(iterations - 1, turtle);
		}

	}

	/*
	 * This recursive function creates a Koch curve which can be used to create a
	 * Snowflake fractal
	 */
	static void Snowflake(int length, int times, Turtle turtle, long color) {
		if (times == 0) {
			turtle.forward(length);
			return;
		} else {
			Snowflake(length / 3, times - 1, turtle, color);
			turtle.left(60);
			Snowflake(length / 3, times - 1, turtle, color);
			turtle.right(120);
			Snowflake(length / 3, times - 1, turtle, color);
			turtle.left(60);
			Snowflake(length / 3, times - 1, turtle, color);

		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Add Method Tests
		System.out.println(Add(0)); // Output: 0
		System.out.println(Add(3)); // Output: 6
		System.out.println(Add(13)); // Output: 91
		System.out.println(Add(154)); // Output: 11935

		// Fibonacci Method Tests
		System.out.println(Fibonacci(1, 1, 1)); // Output: 1
		System.out.println(Fibonacci(13, 21, 5)); // Output: 21 31 55 89 144
		System.out.println(Fibonacci(55, 89, 5)); // Output: 89 144 233 377 610
		System.out.println(Fibonacci(1, 1, 10)); // Output: 1 2 3 5 8 13 21 34 55 89
		System.out.println(Fibonacci(1, 1, 13)); // Output: 1 2 3 5 8 13 21 34 55 89 144 233 377

		// DrawSquareSpiral Method Tests
		Turtle turtle = new Turtle();
		// The 'turtle.speed(0)' allows the turtle output
		// to be drawn automatically when it runs
		turtle.speed(0);
		DrawSquareSpiral(100, 5, turtle);

		// DrawSpiral Method Tests
		DrawSpiral(100, 72, 0.97, 10, turtle);
		DrawSpiral(100, 121, 0.95, 15, turtle);
		DrawSpiral(100, 80, 0.95, 10, turtle);

		// DrawSpiralWithColors Method Tests
		DrawSpiralWithColors(100, 72, 0.97, 10, turtle);
		DrawSpiralWithColors(100, 121, 0.95, 15, turtle);
		DrawSpiralWithColors(100, 80, 0.95, 10, turtle);

		// DrawWeirdStuff Method Tests
		DrawWeirdStuff(25, turtle);

		// Snowflake Method Tests
		// For all of these method tests
		// we need to turn the turtle right and then call
		// the recursive function to make the Snowflake
		// using the Koch Curve that was create by the
		// Snowflake recursive method
		long color = turtle.penColor(Color.blue); // Setting the Snowflake color
		Snowflake(100, 3, turtle, color);
		turtle.right(120);
		Snowflake(100, 3, turtle, color);
		turtle.right(120);
		Snowflake(100, 3, turtle, color);

		long newColor = turtle.penColor(Color.pink); // Setting the Snowflake color
		Snowflake(100, 3, turtle, newColor);
		turtle.right(120);
		Snowflake(100, 3, turtle, newColor);
		turtle.right(120);
		Snowflake(100, 3, turtle, newColor);

		long anotherColor = turtle.penColor(Color.magenta); // Setting the Snowflake color
		Snowflake(100, 3, turtle, anotherColor);
		turtle.right(120);
		Snowflake(100, 3, turtle, anotherColor);
		turtle.right(120);
		Snowflake(100, 3, turtle, anotherColor);

	}

}
