import java.util.Stack;

public class LSystemInterpreter {

	public int forward;
	public double rightAngle;
	public double leftAngle;
	public double xPosition;
	public double yPosition;
	public double alpha;
	public String axiom;

	/*
	 * Constructor for the LSystemInterpreter class that initializes the forward,
	 * rightAngle, and leftAngle variables
	 */
	public LSystemInterpreter(String axiom, int forward, double rightAngle, double leftAngle) {
		this.axiom = axiom;
		this.forward = forward;
		this.rightAngle = rightAngle;
		this.leftAngle = leftAngle;
	}

	/*
	 * This method is the interpretation part for the LSystem using the string
	 * generated in the Rules class
	 * 
	 * F : Move the Turtle forward x units - : Rotate the Turtle left by x degrees +
	 * : Rotate the Turtle right by x degrees # : Increment the forward value by
	 * double ! : Decrement the forward value by dividing by (forward + forward) ( :
	 * Decrement left angle by right angle ) : Increment right angle by right angle
	 * The value to move the Turtle forward and the value to rotate the Turtle
	 * either right or left are values that you can decide by passing the values to
	 * the LSystemInterpreter constructor
	 */
	public void LSystemTurtle() {
		//		Rules r1 = new Rules(); // new Rules object
		Turtle turtle = new Turtle(); // new Turtle object
		turtle.speed(0);
		Stack<Double> stack = new Stack<Double>();

		// Create a for loop that runs through each character of the axiom
		// and if it equals a certain conditon such as "F" , "+" , or "-"
		// then the LSystem will interpret that and move the Turtle forward
		// or rotate the Turtle either left or right
		for (int i = 0; i < axiom.length(); i++) {
			if (axiom.substring(i, i + 1).equals("F")) {
				turtle.forward(forward);
			}

			if (axiom.substring(i, i + 1).equals("+")) {
				alpha += rightAngle;
				turtle.right(rightAngle);
			}

			if (axiom.substring(i, i + 1).equals("-")) {
				alpha -= leftAngle;
				turtle.left(leftAngle);
			}

			if (axiom.substring(i, i + 1).equals("#")) {
				turtle.forward(forward + forward);
			}

			if (axiom.substring(i, i + 1).equals("!")) {
				turtle.forward(forward - (forward + forward));
			}

			if (axiom.substring(i, i + 1).equals(")")) {
				alpha += (rightAngle + rightAngle);
				turtle.right(rightAngle + rightAngle);
			}

			if (axiom.substring(i, i + 1).equals("(")) {
				alpha -= (leftAngle - rightAngle);
				turtle.left(leftAngle - rightAngle);
			}

			// If the axiom at a certain index or character equals "[" then
			// we push the current position state and rotation state of the Turtle
			// onto the Stack

			// Obtain the x and y position, and the direction of the Turtle so it can be
			// saved
			// by using the .getX() , .getY() , and .getDirection() method, which is then
			// stored in the Stack to set the new position of the Turtle
			if (axiom.substring(i, i + 1).equals("[")) {
				stack.push(turtle.getY());
				stack.push(turtle.getX());
				stack.push(turtle.getDirection());
			}

			// If the axiom at a certain index or character equals "]" then
			// it pops the location and rotation state of the Turtle from the stack
			// and sets the Turtle's new position

			// Note that the pop() removes elements in the stack from reverse order
			if (axiom.substring(i, i + 1).equals("]")) {
				turtle.setDirection(stack.pop());
				turtle.up();
				turtle.setPosition(stack.pop(), stack.pop());
				turtle.down();
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LSystem l1 = new LSystem(); // New LSystem object
		l1.setRule("F[+FF][-FF]F[-F][+F]F");
		l1.setCondition("F");
		l1.setLoops(4);
		l1.setString("F");
		System.out.println(l1.checkRule());
		System.out.println(l1.getString().length());
		LSystemInterpreter ls1 = new LSystemInterpreter(l1.getString(), 14, 22.5, 22.5);
		ls1.LSystemTurtle();
	}

}
