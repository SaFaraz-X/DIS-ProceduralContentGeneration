import java.util.ArrayList;

public class LSystem {

	// Initializing necessary variables for the Rules class
	public ArrayList<String> ruleList = new ArrayList<String>();
	public ArrayList<String> conditionList = new ArrayList<String>();
	public String rule;
	public String someCondition;
	public int loops;
	public String firstString;

	/*
	 * Constructor for the LSystem class
	 */
	public LSystem() {

	}

	/*
	 * A getter method that returns a String rule
	 */
	public String getRule() {
		return this.rule;
	}

	/*
	 * A setter method that sets the String rule and adds the rule to the ArrayList
	 * ruleList
	 * 
	 * The ArrayList allows multiple rules to be created and stored
	 */
	public void setRule(String rule) {
		this.rule = rule;
		this.ruleList.add(this.rule);
	}

	/*
	 * A getter method that returns a String condition
	 */
	public String getCondition() {
		return this.someCondition;
	}

	/*
	 * A setter method that sets the String condition and adds the condition to the
	 * ArrayList conditionList
	 * 
	 * The ArrayList allows multiple conditions to be set and stored
	 */
	public void setCondition(String someCondition) {
		this.someCondition = someCondition;
		this.conditionList.add(this.someCondition);
	}

	/*
	 * A getter method that returns the number of loops that should be iterated
	 * through the LSystem
	 */
	public int getLoops() {
		return this.loops;
	}

	/*
	 * A setter method sets the number of loops that should be iterated through the
	 * LSystem
	 */
	public void setLoops(int loops) {
		this.loops = loops;
	}

	/*
	 * A getter method that returns the String axiom
	 */
	public String getString() {
		return this.firstString;
	}

	/*
	 * A setter method that sets the String axiom used for the LSystem
	 */
	public void setString(String firstString) {
		this.firstString = firstString;
	}

	/*
	 * This method checks if the axiom (firstString) at each index / character is
	 * equal to any condition from the conditionList and if that is true then the
	 * axiom will apply the rule from the ruleList that aligns with the condition
	 * 
	 * This method returns the evaluated axiom after it finishes iterating through
	 * the number of loops set (this.loops)
	 */
	public String checkRule() {
		for (int i = 0; i < this.loops; i++) {
			String newText = "";
			for (int j = 0; j < this.firstString.length(); j++) {
				String subText = this.firstString.substring(j, j + 1);
				for (int z = 0; z < this.ruleList.size(); z++) {
					if (!subText.equals(this.conditionList.get(z))) {
						newText += subText;
					} else {
						newText += this.ruleList.get(z);
					}
				}

			}

			this.firstString = newText;

		}

		return this.firstString;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// New LSystem object
		LSystem l1 = new LSystem();
		// New Rules object
		l1.setRule("FF+[+F-F-F]-[-F+F+F");
		l1.setCondition("F");
		l1.setCondition("]");
		l1.setCondition("[");
		l1.setLoops(4);
		l1.setString("F");
		System.out.println(l1.checkRule());

	}

}
