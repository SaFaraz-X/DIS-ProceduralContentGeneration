import java.awt.Color; 
import java.awt.image.BufferedImage;

public class Lab4 {

	/*
	 * This function changes all the pixels in the BufferedImage img to the Color c
	 * by looping through each pixel of the image provided by img.getWidth() and
	 * img.getHeight() and the color is set using img.setRGB(x, y, c.getRGB()) with
	 * x and y being the position of each pixel
	 */
	public static void ColourAllPixels(BufferedImage img, Color c) {
		for (int x = 0; x < img.getWidth(); x++) {
			for (int y = 0; y < img.getHeight(); y++) {
				img.setRGB(x, y, c.getRGB());
			}
		}
	}

	/*
	 * This function draws a checkerboard pattern in an image. Each square within
	 * the pattern is determined by the x and y position of each pixel which is then
	 * used within the Utility.DrawFilledRect to fill in each square. For each
	 * square that's created a new color is used, creating a checkerboard pattern
	 */
	public static void CheckerBoard(BufferedImage img, int squareSize, Color c1, Color c2) {
		int x = 0;
		for (int i = 0; i <= squareSize; i++) {
			int y = 0;
			for (int j = 0; j <= squareSize; j++) {
				if ((i + j) % 2 != 0) {
					Utility.DrawFilledRect(img, x, y, squareSize, squareSize, c2);
				} else {
					Utility.DrawFilledRect(img, x, y, squareSize, squareSize, c1);
				}
				y += 10;
			}
			x += 10;
		}
	}

	/*
	 * A recursive function that draws increasingly smaller rectangles while
	 * switching between Color c1 and Color c2. The recursive function terminates
	 * once the size is less than or equal to zero
	 * 
	 * The startX and startY parameters increment by the thickness to create an even
	 * pattern when the function drawns an increasingly smaller rectangle
	 * 
	 * The image size equals (size - (thickness * 2)) so that the size gets smaller
	 * in each iteration
	 */
	public static void InfinitePattern(BufferedImage img, int startX, int startY, int size, int thickness, Color c1,
			Color c2) {
		if (size <= 0) {
			return;
		} else {
			Utility.DrawFilledRect(img, startX, startY, size, size, c1);
			InfinitePattern(img, startX += thickness, startY += thickness, size = size - (thickness * 2), thickness, c1,
					c2);
			Utility.DrawFilledRect(img, startX, startY, size, size, c2);
			InfinitePattern(img, startX += thickness, startY += thickness, size = size - (thickness * 2), thickness, c1,
					c2);
		}

	}

	/*
	 * Creates an inifnite checkerboard pattern by taking the InfinitePattern
	 * function and using it in the CheckerBoard function The position of each
	 * square for the checkerboard is determined by the x and y position whose
	 * values increment by 10 to create an even checkerboard
	 */
	public static void InfiniteCheckerBoard(BufferedImage img, int squareSize, Color c1, Color c2) {
		int x = 0;
		for (int i = 0; i <= squareSize; i++) {
			int y = 0;
			for (int j = 0; j <= squareSize; j++) {
				Lab4.InfinitePattern(img, x, y, squareSize, 1, c1, c2);
				y += 10;
			}

			x += 10;
		}
	}

	/*
	 * This function loops through each pixel within an image so it can draw Perlin
	 * noise on a texture.
	 * 
	 * 
	 * This function sets the noise value of each pixel using the noise function
	 * from the PerlinNoise class (the higher the values used for Perlin noise, the
	 * more zommed in the result is
	 * 
	 * Using the map function from the Utility class, we can map numbers from one
	 * range to another which is useful for mapping the result of the Perlin noise
	 * to a color
	 */
	public static void PerlinNoise(BufferedImage img) {
		PerlinNoise pn = new PerlinNoise(100);
		for (int x = 0; x < img.getWidth(); x++) {
			for (int y = 0; y < img.getHeight(); y++) {
				double newNoise = pn.noise(x / 10.0, y / 10.0);
				int result = (int) Utility.map(newNoise, -1, 1, 0, 255);
				Color newColor = new Color(result, result, result);
				img.setRGB(x, y, newColor.getRGB());
			}
		}
	}

	/*
	 * This function loops through each pixel within an image so it can draw simplex
	 * noise on a texture
	 * 
	 * This function sets the noise value of each pixel using the noise function
	 * from the SimplexNoise class
	 * 
	 * Using the map function from the Utility class, we can map numbers from one
	 * range to another which is useful for mapping the result of the Simplex noise
	 * to a color
	 */
	public static void SimplexNoise(BufferedImage img) {
		for (int x = 0; x < img.getWidth(); x++) {
			for (int y = 0; y < img.getHeight(); y++) {
				double newNoise = SimplexNoise.noise(x / 10.0, y / 10.0);
				int result = (int) Utility.map(newNoise, -1, 1, 0, 255);
				Color newColor = new Color(result, result, result);
				img.setRGB(x, y, newColor.getRGB());
			}
		}
	}

	/*
	 * This function loops through each pixel within an image so it can draw white
	 * noise on a texture
	 * 
	 * We use the Math.random() function to generate White Noise
	 * 
	 * Using the map function from the Utility class, we can map numbers from one
	 * range to another which is useful for mapping the result to a color
	 */
	public static void WhiteNoise(BufferedImage img) {
		for (int x = 0; x < img.getWidth(); x++) {
			for (int y = 0; y < img.getHeight(); y++) {
				double newValue = Math.random();
				int result = (int) Utility.map(newValue, 0, 1, 0, 255);
				System.out.println(result);
				Color newColor = new Color(result, result, result);
				img.setRGB(x, y, newColor.getRGB());
			}
		}
	}

	/**
	 * Part 3: CITY description
	 * 
	 * Properties of a PCG solution: - Speed: - Reliability: - Controllability: -
	 * Expressivity and Diversity: - Creativity and Believability:
	 * 
	 * Variables that the user can control: - Small City - Canal? - Medium City -
	 * Canal? - Big City - Harbor? - Zones Weighing
	 * 
	 * The buildinggeneration system uses the location of buildings inthe form of a
	 * grid coordinates as a seed for building generation.The appearance of each
	 * building is determined by this seedincluding properties such as height, width
	 * and number of floors.Generating buildings using a similar set of numbers such
	 * as neighbouring grid coordinates can result in similar looking buildings, so
	 * to overcome this a hashing function shown in Figure 18 is implemented in
	 * order to provide more random distribution.
	 * 
	 * 
	 * What will the city contain? - Roads - Can make it a grid like American system
	 * or like European system (starts from city) - How to draw roads? Could be a
	 * line that connects to lines - Canal + Bridges - Residential communities
	 * 
	 * - Commercial zones (shopping center) - Only contain pedestrian sidewalks, no
	 * roads for driving
	 * 
	 * Plan: Start off by creating the layout of the zones, where the zones will be
	 * placed within the city Then all the space that's left will be occupied by the
	 * roads
	 */

	public static void main(String[] args) {

		// Create an image of width 100 and height 100
		BufferedImage img;
		img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
		// Saves the created image
		Utility.SaveImage(img, ".//Images//TestImage.png");

		// ColourAllPixels Image
		ColourAllPixels(img, Color.blue);
		Utility.SaveImage(img, ".//Images//ColourAllPixels.png");

		// CheckerBoard Image
		CheckerBoard(img, 10, Color.black, Color.white);
		Utility.SaveImage(img, ".//Images//CheckerBoard.png");

		// InfinitePattern Image
		InfinitePattern(img, 0, 0, img.getWidth(), 10, Color.blue, Color.black);
		Utility.SaveImage(img, ".//Images//InfinitePattern.png");

		// InfiniteCheckerBoard Image
		InfiniteCheckerBoard(img, 10, Color.black, Color.white);
		Utility.SaveImage(img, ".//Images//InfiniteCheckerBoard.png");

		// PerlinNoise Image
		PerlinNoise(img);
		Utility.SaveImage(img, ".//Images//Perlin.png");

		// SimplexNoise Image
		SimplexNoise(img);
		Utility.SaveImage(img, ".//Images//Simplex.png");

		// WhiteNoise Image
		WhiteNoise(img);
		Utility.SaveImage(img, ".//Images//WhiteNoise.png");
	}

}
