import java.awt.Color;

class HelloWorld

{
	public static void DrawRectangle(Turtle t, 
			int xPos, int yPos, int width, int height) {
//		width = 150;
//		height = 150;
		for(int i = 0; i < 150; i++) {
			t.forward(100);
			t.up();
			t.setPosition(i, i);
			t.down();
			t.forward(100);
		}
		
		
	}
	
	public static void main(String args[])
	{
		System.out.print("Hello World!");
		//Creates the graphical window - this is where you will get to draw
		//everything
		Turtle turtle = new Turtle();
		//Move turtle forward
		turtle.penColor(Color.red);
		turtle.forward(100);
		//Rotate 120 degrees to the left
		turtle.left(120);
		//Move forward 100 pixels (notice that now the turtle will move
		//forward relative to the previous rotation)
		turtle.forward(100);
		//Rotate 120 degrees left (relative to the previous orientation)
		turtle.left(120);
		//Move forward 100 pixels (relative to the previous orientation)
		turtle.forward(100);
		turtle.penColor(Color.black);
		turtle.left(30);
		turtle.forward(100);
		turtle.left(90);
		turtle.forward(100);
		turtle.left(90);
		turtle.forward(100);
		// Creating the tree next to the house
//		turtle.penColor(Color.white);
		turtle.up();
		turtle.setPosition(150, 0);
		turtle.down();
//		turtle.penColor(Color.black);
		turtle.left(180);
		turtle.forward(100);
		turtle.left(90);
		turtle.forward(10);
		turtle.left(90);
		turtle.forward(100);
		turtle.penColor(Color.white);
		turtle.left(90);
		turtle.forward(5);
		turtle.dot(Color.green, 40);
		turtle.up();
		turtle.setPosition(3000, 0);
		
//		Turtle newTurtle = new Turtle();
//		DrawRectangle(newTurtle, 15, 15, 25, 25);
	}
}