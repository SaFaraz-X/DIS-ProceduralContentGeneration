
public class Node {

	/**
	 * Initalize the node's x position, y position, dungeon width, and dungeon
	 * height
	 */
	public int xPosition;
	public int yPosition;
	public int dungeonWidth;
	public int dungeonHeight;

	/**
	 * Initalize the left node and right node
	 */
	public Node leftNode;
	public Node rightNode;

	/**
	 * Class constructor All four variables / parameters determine the points and
	 * size of each node area within the dungeon
	 * 
	 * @param xPosition
	 * @param yPosition
	 * @param dungeonWidth
	 * @param dungeonHeight
	 */
	public Node(int xPosition, int yPosition, int dungeonWidth, int dungeonHeight) {
		this.xPosition = xPosition;
		this.yPosition = yPosition;
		this.dungeonWidth = dungeonWidth;
		this.dungeonHeight = dungeonHeight;

		leftNode = null;
		rightNode = null;

	}

	/**
	 * Setter method for the left node
	 * 
	 * @param leftNode
	 */
	public void setLeft(Node leftNode) {
		this.leftNode = leftNode;

	}

	/**
	 * Getter method for the left node
	 * 
	 * @return returns the left node
	 */
	public Node getLeft() {
		return this.leftNode;
	}

	/**
	 * Setter method for the right node
	 * 
	 * @param rightNode
	 */
	public void setRight(Node rightNode) {
		this.rightNode = rightNode;
	}

	/**
	 * Getter method for the right node
	 * 
	 * @return returns the right node
	 */
	public Node getRight() {
		return this.rightNode;
	}

	/**
	 * Method used to check if two nodes share the same parent node
	 */
	public boolean checkParentNode(Node parentNode, Node leftNode, Node rightNode) {
		if (parentNode.getLeft() == leftNode && parentNode.getRight() == rightNode) {
			return true;
		} else {
			return false;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
