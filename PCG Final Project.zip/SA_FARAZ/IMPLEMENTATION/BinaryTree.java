import java.util.Random;
import java.awt.Color;
import java.awt.image.BufferedImage;

public class BinaryTree {

	Random random = new Random();

	/**
	 * Declare type Node for root, leftNode, and rightNode variables Declare minSize
	 * variable to define the minimum size of a dungeon room
	 * 
	 */
	public Node root;
	public Node leftNode;
	public Node rightNode;
	public static int minSize = 7;

	/**
	 * Instantiate the Node class
	 * 
	 */
	public Node nodeClass = new Node(0, 0, 0, 0);

	/**
	 * BinaryTree constructor
	 * 
	 * @param root sets and contains the entire dungeon area
	 */
	public BinaryTree(Node root) {
		this.root = root;
	}

	/**
	 * addNode method is used to set and maintain the Binary Search Tree This method
	 * calls upon the setLeft and setRight method from the Node class to set either
	 * the left or right node of a parent node
	 * 
	 * @param parentNode
	 * @param childNode  is either the left node or right node that we want to place
	 *                   into the tree
	 * @param direction  determines if the node is left or right
	 * @return boolean true if the node was correctly added
	 */
	public boolean addNode(Node parentNode, Node childNode, String direction) {
		if (direction.equals("Left")) {
			parentNode.setLeft(childNode);
		} else {
			parentNode.setRight(childNode);
		}

		return true;
	}

	/**
	 * This method obtain a random boolean value for the 'directionDivision'
	 * variable If the value is true then we will split our dungeon vertically,
	 * otherwise we will split horizontally This method will continuously split the
	 * dungeon by half its width or height The newly created cells will then be
	 * assigned to the left and right nodes, and then added to the BST Then the
	 * method calls upon the Utility class' DrawEmptyRect method to create the cells
	 * 
	 * @param parentNode is the node or cell that we want to divide into two smaller
	 *                   cells
	 * @param img        is the image we want to create for our dungeon, used in the
	 *                   Utility class
	 * @param thickness  determines how thick we want the outlines of the cells
	 * @param c          determines the color of the cells
	 * @return true if success
	 */
	public boolean cellSplit(Node parentNode, BufferedImage img, int thickness, Color c) {
		boolean directionDivision = random.nextBoolean();
		if (directionDivision == true) {
			// Split dungeon vertically if true
			Node leftNode = new Node(parentNode.xPosition, parentNode.yPosition, parentNode.dungeonWidth / 2,
					parentNode.dungeonHeight);
			Node rightNode = new Node(parentNode.xPosition + (parentNode.dungeonWidth / 2), parentNode.yPosition,
					parentNode.dungeonWidth / 2, parentNode.dungeonHeight);

			// Assign each new cell to a left and right node
			nodeClass.setLeft(leftNode);
			nodeClass.setRight(rightNode);

			// Add the two new cells or nodes into the BST
			addNode(parentNode, leftNode, "Left");
			addNode(parentNode, rightNode, "Right");

			// Draw the cells using the Utility class
			Utility.DrawEmptyRect(img, leftNode.xPosition, leftNode.yPosition, leftNode.dungeonWidth,
					leftNode.dungeonHeight, thickness, c);
			Utility.DrawEmptyRect(img, rightNode.xPosition, rightNode.yPosition, rightNode.dungeonWidth,
					rightNode.dungeonHeight, thickness, c);

		} else {
			// Split dungeon horizontally if false
			Node leftNode = new Node(parentNode.xPosition, parentNode.yPosition, parentNode.dungeonWidth,
					parentNode.dungeonHeight / 2);
			Node rightNode = new Node(parentNode.xPosition, parentNode.yPosition + (parentNode.dungeonHeight / 2),
					parentNode.dungeonWidth, parentNode.dungeonHeight / 2);
			// Assign each new cell to a left and right node
			nodeClass.setLeft(leftNode);
			nodeClass.setRight(rightNode);
			// Add the two new cells or nodes into the BST
			addNode(parentNode, leftNode, "Left");
			addNode(parentNode, rightNode, "Right");
			// Draw the cells using the Utility class
			Utility.DrawEmptyRect(img, leftNode.xPosition, leftNode.yPosition, leftNode.dungeonWidth,
					leftNode.dungeonHeight, thickness, c);
			Utility.DrawEmptyRect(img, rightNode.xPosition, rightNode.yPosition, rightNode.dungeonWidth,
					rightNode.dungeonHeight, thickness, c);
		}

		return true;
	}

	/**
	 * Method checks if the node parameter is a leaf node If true, obtain a new y
	 * position, x position, dungeon width, and dungeon height value using the
	 * random function This function utilizes the minSize variable so that it
	 * ensures that the dungeon rooms are not too small or too big
	 * 
	 * @param node is the cell that we want to create the room within
	 * @param img
	 * @param c
	 * @return true if successful, false if not successful
	 */
	public boolean createRooms(Node node, BufferedImage img, Color c) {
		// Create rooms inside nodes / cells that do not have any child nodes
		int randomX;
		int randomY;
		int newDungeonHeight;
		int newDungeonWidth;

		// Check if the nodes are leaf nodes
		if (node.getLeft() == null && node.getRight() == null) {
			// Obtain new y position randomly
			if (node.dungeonHeight - minSize > 0) {
				randomY = random.nextInt(node.dungeonHeight - minSize);
			} else {
				randomY = 0;
			}

			// Obtain new x position randomly
			if (node.dungeonWidth - minSize > 0) {
				randomX = random.nextInt(node.dungeonWidth - minSize);
			} else {
				randomX = 0;
			}

			// Obtain new dungeon width and new dungeon height values
			newDungeonHeight = Math.max(random.nextInt(node.dungeonHeight - randomY), minSize);
			newDungeonWidth = Math.max(random.nextInt(node.dungeonWidth - randomX), minSize);

			Node dungeonRoom = new Node(randomX + node.xPosition, randomY + node.yPosition, newDungeonWidth,
					newDungeonHeight);

			// Assign the values back to the original node so that it saves the values to be
			// used later on
			node.xPosition = randomX + node.xPosition;
			node.yPosition = randomY + node.yPosition;
			node.dungeonWidth = newDungeonWidth;
			node.dungeonHeight = newDungeonHeight;

			// Draw the actual dungeon rooms
			Utility.DrawFilledRect(img, dungeonRoom.xPosition, dungeonRoom.yPosition, dungeonRoom.dungeonWidth,
					dungeonRoom.dungeonHeight, c);
			return true;

		} else {
			return false;
		}
	}

	/**
	 * The method creates corridors within the dungeon generation system First, the
	 * method will check if two nodes share the same parent node using the
	 * checkParentNode method from the Node class
	 * 
	 * @param img
	 * @param parentNode used to check if two nodes share this parent node
	 * @param leftNode   connect to rightNode if they are sibling nodes
	 * @param rightNode  connect to leftNode if they are sibling nodes
	 * @param thickness  determines how thick we want our corridors to be
	 * @param c          determines the color of the corridors
	 * @return
	 */
	public boolean connectRooms(BufferedImage img, Node parentNode, Node leftNode, Node rightNode, int thickness,
			Color c) {
		// Check if two nodes share the same parent node
		if (nodeClass.checkParentNode(parentNode, leftNode, rightNode)) {
			// Call the DrawLine method from the Utility class to connect dungeon rooms
			Utility.DrawLine(img, leftNode.xPosition + (leftNode.dungeonWidth / 2),
					leftNode.yPosition + (leftNode.dungeonHeight / 2),
					rightNode.xPosition + (rightNode.dungeonWidth / 2),
					rightNode.yPosition + (rightNode.dungeonHeight / 2), thickness, c);
			System.out.println(true);
			return true;
		} else {
			System.out.println(false);
			return false;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Create an image of width 100 and height 100
		BufferedImage img;
		img = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);

		// Set the dungeon / root node
		Node root = new Node(0, 0, 100, 100);
		BinaryTree tree = new BinaryTree(root);

		// cellSplit method
		tree.cellSplit(root, img, 1, Color.gray);
		tree.cellSplit(root.getLeft(), img, 1, Color.gray);
		tree.cellSplit(root.getRight(), img, 1, Color.gray);

		tree.cellSplit(root.getLeft().getLeft(), img, 1, Color.gray);
		tree.cellSplit(root.getLeft().getRight(), img, 1, Color.gray);
		tree.cellSplit(root.getRight().getRight(), img, 1, Color.gray);
		tree.cellSplit(root.getRight().getLeft(), img, 1, Color.gray);

		// createRooms method
		tree.createRooms(root.getLeft().getLeft().getLeft(), img, Color.white);
		tree.createRooms(root.getLeft().getLeft().getRight(), img, Color.white);

		tree.createRooms(root.getLeft().getRight().getLeft(), img, Color.white);
		tree.createRooms(root.getLeft().getRight().getRight(), img, Color.white);

		tree.createRooms(root.getRight().getRight().getLeft(), img, Color.white);
		tree.createRooms(root.getRight().getRight().getRight(), img, Color.white);

		tree.createRooms(root.getRight().getLeft().getLeft(), img, Color.white);
		tree.createRooms(root.getRight().getLeft().getRight(), img, Color.white);

		// connectRooms method
		tree.connectRooms(img, root.getLeft().getLeft(), root.getLeft().getLeft().getLeft(),
				root.getLeft().getLeft().getRight(), 1, Color.white);
		tree.connectRooms(img, root.getLeft().getRight(), root.getLeft().getRight().getLeft(),
				root.getLeft().getRight().getRight(), 1, Color.white);

		tree.connectRooms(img, root.getRight().getLeft(), root.getRight().getLeft().getLeft(),
				root.getRight().getLeft().getRight(), 1, Color.white);
		tree.connectRooms(img, root.getRight().getRight(), root.getRight().getRight().getLeft(),
				root.getRight().getRight().getRight(), 1, Color.white);

		// Saves the created image
		Utility.SaveImage(img, "/Users/sauhilfaraz/Desktop/PCG Final Project/Images/testImage.png");
	}

} 